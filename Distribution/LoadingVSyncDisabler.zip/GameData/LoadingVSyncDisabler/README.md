# LoadingVSyncDisabler
Lightweight Kerbal Space Program plugin to ensure that VSync is disabled during the loading screen, code &amp; concept shameless copied from Gameslinx's Parallax mod.
